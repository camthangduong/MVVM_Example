﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace MyActionsLibrary
{
    public class FollowMouseAction : Microsoft.Expression.Interactivity.TargetedTriggerAction<Canvas>
    {
        public FrameworkElement Element
        {
            get { return (FrameworkElement)GetValue(ElementProperty); }
            set { SetValue(ElementProperty, value); }
        }

        // Using a DependencyProperty as the backing store for element.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ElementProperty =
            DependencyProperty.Register("Element", typeof(FrameworkElement), typeof(FollowMouseAction), new UIPropertyMetadata(null));

        protected override void Invoke(object parameter)
        {
            Point pt = Mouse.GetPosition(this.Target);
            if (Element != null)
            {
                Element.SetValue(Canvas.LeftProperty, pt.X);
                Element.SetValue(Canvas.TopProperty, pt.Y);
            }
        }
    }
}
