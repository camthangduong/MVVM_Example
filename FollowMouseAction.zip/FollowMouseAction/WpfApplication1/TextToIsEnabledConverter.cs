﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace WpfApplication1
{
    public class TextToIsEnabledConverter:IMultiValueConverter
    {
        #region IMultiValueConverter Members

        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string txt1 = values[0].ToString();
            string txt2 = values[1].ToString();

            return !string.IsNullOrEmpty(txt1) && !string.IsNullOrEmpty(txt2); 
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((bool)value)
            {
                return new object[] {"Forced","Forced" };
            }
            return null;
        }

        #endregion
    }
}
