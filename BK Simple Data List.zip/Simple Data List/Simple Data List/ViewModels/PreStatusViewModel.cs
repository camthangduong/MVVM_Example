﻿using Simple_Data_List.Library;
using Simple_Data_List.Models;
using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows.Controls;
using System.Windows.Data;

namespace Simple_Data_List.ViewModels
{
    public class PreStatusViewModel : ViewModelBase
    {

        public RelayCommand<CheckBox> CheckBoxChange { get; private set; }

        private BackgroundWorker backgroundWorker;
        private System.Collections.ObjectModel.ObservableCollection<ClientInfo> clientList;
        private ICollectionView groupedClients;
        private MainWindowViewModel mainVM;

        public ICollectionView GroupClients
        {
            get { return groupedClients; }
            set
            {
                groupedClients = value;
                NotifyPropertyChanged("ClientList");
                SetProperty(ref groupedClients, value);
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="_mainVM"></param>
        public PreStatusViewModel(MainWindowViewModel _mainVM)
        {
            // Assign the Navigation event
            CheckBoxChange = new RelayCommand<CheckBox>(OnCheckBoxChange);
            mainVM = _mainVM;
            clientList = new System.Collections.ObjectModel.ObservableCollection<ClientInfo>();
            // clientList.CollectionChanged += WhenCollectionChanged;
            backgroundWorker = new BackgroundWorker();
            // Background Worker Process
            backgroundWorker.DoWork += BKDoWork;
            backgroundWorker.RunWorkerCompleted += BKCompleted;
            // Change status
            backgroundWorker.WorkerReportsProgress = true;
            backgroundWorker.ProgressChanged += BKChangedState;
            // Cancellation
            backgroundWorker.WorkerSupportsCancellation = true;
            // Start the worker
            if (!backgroundWorker.IsBusy)
            {
                mainVM.ToggleEnableProp(false);
                backgroundWorker.RunWorkerAsync();
            }
        }

        private void OnCheckBoxChange(object sender)
        {
            // Object sender
            CheckBox obj = (CheckBox)sender;
            int index = Int32.Parse(obj.Tag.ToString());
            if (clientList[index].IsEnable)
            {
                clientList[index].Selected = obj.IsChecked == true;
            }

        }

        /// <summary>
        /// Run when background worker status change during the process
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BKChangedState(object sender, ProgressChangedEventArgs e)
        {
            // throw new NotImplementedException();
        }

        /// <summary>
        /// Run when background worker has completed the job
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BKCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            GroupClients = new ListCollectionView(clientList);
            GroupClients.GroupDescriptions.Add(new PropertyGroupDescription("Group"));
            // GroupClients.CollectionChanged += WhenCollectionChanged;
            mainVM.ToggleEnableProp(true);
        }

        private void WhenCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (sender != null)
            {
            }

        }

        /// <summary>
        /// Run when background worker start
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BKDoWork(object sender, DoWorkEventArgs e)
        {
            GhostDataUtilities ghostUtil = new GhostDataUtilities();
            clientList = ghostUtil.GhostPreStatusData();
        }

        /// <summary>
        /// The list of client file
        /// </summary>
        public System.Collections.ObjectModel.ObservableCollection<ClientInfo> ClientList
        {
            get { return clientList; }
            private set { clientList = value; SetProperty(ref clientList, value); }
        }
    }
}
