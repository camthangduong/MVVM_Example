﻿using System.Windows.Controls;

namespace Simple_Data_List.Views
{
    /// <summary>
    /// Interaction logic for PreStatusView.xaml
    /// </summary>
    public partial class PreStatusView : UserControl
    {
        public PreStatusView()
        {
            InitializeComponent();
        }
    }
}
