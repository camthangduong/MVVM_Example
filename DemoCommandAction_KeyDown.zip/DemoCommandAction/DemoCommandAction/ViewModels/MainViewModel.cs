﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DemoCommandAction
{
	public class MainViewModel
	{
		//Commands
        private ICommand _comHoverOnRecCommand;
		
		public MainViewModel()
		{
			
		}

        public ICommand HoverOnRecCommand
        {
            get
            {
                if (_comHoverOnRecCommand == null)
                {
                    _comHoverOnRecCommand = new RelayCommand<object>(HoverOverRec_Executed, HoverOverRec_CanExecute);
                }
                return _comHoverOnRecCommand;
            }
        }

        private bool HoverOverRec_CanExecute(object parameter)
        {
            return true;
        }
        private void HoverOverRec_Executed(object parameter)
        {
            KeyEventArgs args=parameter as KeyEventArgs;
            if (args != null)
            {
                MessageBox.Show("Pressed " + args.Key.ToString());
            }
            //Process args.Key
        }
	}
}