﻿using Silent_Update.Utilities;

namespace Silent_Update.ViewModels
{
    class SettingHealthCheckViewModel : BindableBase
    {
    }
}
