﻿namespace Silent_Update.DAL
{
    public class ClientInfoUtil
    {
    }
}
