﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoApp.Viewmodel
{
    public enum ViewModelMessages
    {
        CustomerDeleted,
        ShowError,
        NotificationMessage
    };
}
