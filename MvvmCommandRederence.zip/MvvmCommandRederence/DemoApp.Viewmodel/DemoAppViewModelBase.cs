﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MVVm.Core;
using DemoApp.DataAccess;
using DemoApp.Settings;

namespace DemoApp.Viewmodel
{
    public class DemoAppViewModelBase : MediatorEnabledViewModel<ViewModelMessages>
    {
        public CustomerRepository CustomerRepository
        {
            get { return CustomerRepository.SingleTon; }
        }
    }
}
