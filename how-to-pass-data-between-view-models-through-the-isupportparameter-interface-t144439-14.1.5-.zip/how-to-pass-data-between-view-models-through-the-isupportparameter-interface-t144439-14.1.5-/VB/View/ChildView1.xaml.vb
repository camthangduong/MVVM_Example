﻿Imports System.Windows.Controls

Namespace Example.View
    Partial Public Class ChildView1
        Inherits UserControl

        Public Sub New()
            InitializeComponent()
        End Sub
    End Class
End Namespace
