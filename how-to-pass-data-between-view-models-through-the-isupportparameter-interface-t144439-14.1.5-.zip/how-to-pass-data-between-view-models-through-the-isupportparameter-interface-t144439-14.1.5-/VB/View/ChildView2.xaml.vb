﻿Imports System.Windows.Controls

Namespace Example.View
    Partial Public Class ChildView2
        Inherits UserControl

        Public Sub New()
            InitializeComponent()
        End Sub
    End Class
End Namespace
