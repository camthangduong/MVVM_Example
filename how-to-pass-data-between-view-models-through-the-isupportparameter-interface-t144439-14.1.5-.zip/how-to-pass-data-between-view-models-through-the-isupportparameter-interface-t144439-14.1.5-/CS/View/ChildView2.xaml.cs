﻿using System.Windows.Controls;

namespace Example.View {
    public partial class ChildView2 : UserControl {
        public ChildView2() {
            InitializeComponent();
        }
    }
}
