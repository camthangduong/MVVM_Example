﻿using System.Windows.Controls;

namespace Example.View {
    public partial class ChildView1 : UserControl {
        public ChildView1() {
            InitializeComponent();
        }
    }
}
