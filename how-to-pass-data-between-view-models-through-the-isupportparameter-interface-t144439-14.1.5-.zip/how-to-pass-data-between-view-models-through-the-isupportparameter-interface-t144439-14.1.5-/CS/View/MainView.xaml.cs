﻿using System.Windows.Controls;

namespace Example.View {
    public partial class MainView : UserControl {
        public MainView() {
            InitializeComponent();
        }
    }
}
