# How to: Pass data between View Models through the ISupportParameter interface


This example demonstrates how you can pass data between View Models through the ISupportParameter interface.<br />Review <a href="https://documentation.devexpress.com/#WPF/CustomDocument17448">this documentation topic</a> to learn more.

<br/>


