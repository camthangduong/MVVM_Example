﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoApp.Viewmodel
{
    public class CustomerViewModelEventArgs:EventArgs 
    {
        public CustomerViewModelEventArgs(CustomerViewModel viewModel)
        {
            ViewModel = viewModel;
        }
        public CustomerViewModel ViewModel { get;private set; }
    }
}
