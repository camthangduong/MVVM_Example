﻿Class Window1 

    Private Sub Window_Loaded(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
       
        ' ''Dim btn As New Button With {.Content = "Click me"}
        ' ''AddHandler btn.Click, Function(senderObj, args) MessageBox.Show("Clicked me")
        ' ''Me.Content = btn

        ' ''Dim firstNo As Integer = 2
        ' ''Dim secNo As Integer = 4

    End Sub

    Private Sub Clicked(ByVal sender As System.Object, ByVal args As RoutedEventArgs)
        MessageBox.Show("Clicked")
    End Sub

    

    Private Sub btnSRRed_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
        Me.Resources("background") = Brushes.Red
    End Sub

    Private Sub btnSRGreen_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
        Me.Resources("background") = Brushes.Green
    End Sub

    Private Sub btnSRBlue_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs)
        Me.Resources("background") = Brushes.Blue
    End Sub
End Class
